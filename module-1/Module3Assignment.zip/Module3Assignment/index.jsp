<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>

<%
/*
Name: Noor Al Salihi
Date: 06/2026
Assignment: Module 1.3
Purpose: Demonstrate a simple JSP page using Java and HTML.
*/
String studentName = "Noor Al Salihi";
%>

<!DOCTYPE html>
<html>
<head>
    <title>My First JSP Page</title>
</head>
<body>

<h1>CSD430 JSP Assignment</h1>

<p>Hello, <%= studentName %>!</p>

<p>Current Date and Time:</p>

<p><%= new java.util.Date() %></p>

</body>
</html>